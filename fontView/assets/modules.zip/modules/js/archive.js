function autocompletebrodcastPlace(data) {
        
    var options = {
        minLength: 1,
        source: function (request, response) {
            $.ajax({
                url: base_url + "/get_boardcast_frequency",
                method: 'post',
                dataType: "json",
                autoFocus:true,
                data: {
                    term: request.term,
                },
                success: function (data) {
                    response(data);
                }
            });
        },
    
        select: function (event, ui) {
            if(ui.item.value !='') {
                $('#prochar_sthan').val(ui.item.value);
            }else{
                $('#prochar_sthan').val('');
            }
            return false;
        }
    };
    $('body').on('keydown.autocomplete', '#prochar_sthan', function() {
        $(this).autocomplete(options);
    });
}

function autocompletefilmActor(data) {
        
    var options = {
        minLength: 1,
        source: function (request, response) {
            $.ajax({
                url: base_url + "/get_film_actor",
                method: 'post',
                dataType: "json",
                autoFocus:true,
                data: {
                    term: request.term,
                },
                success: function (data) {
                    response(data);
                }
            });
        },
    
        select: function (event, ui) {
            if(ui.item.name !='') {
                $('#film_actor').val(ui.item.name);
            }else{
                $('#film_actor').val('');
            }
            return false;
        }
    };
    $('body').on('keydown.autocomplete', '#film_actor', function() {
        $(this).autocomplete(options);
    });
}


function autocompletefilmDirector(data) {
        
    var options = {
        minLength: 1,
        source: function (request, response) {
            $.ajax({
                url: base_url + "/get_film_director",
                method: 'post',
                dataType: "json",
                autoFocus:true,
                data: {
                    term: request.term,
                },
                success: function (data) {
                    response(data);
                }
            });
        },
    
        select: function (event, ui) {
            if(ui.item.name !='') {
                $('#film_director').val(ui.item.name);
            }else{
                $('#film_director').val('');
            }
            return false;
        }
    };
    $('body').on('keydown.autocomplete', '#film_director', function() {
        $(this).autocomplete(options);
    });
}

//////// audio player start ///////

player = document.getElementById("player");

var currentSong  = '';

function audioAction(songName,id) {
    $(".playbtn").html("<i class='fa fa-play'></i>");
    if(currentSong != songName) {
        player.src=songName;
        player.load(); // load song
        player.play(); // start new song
        $("#btn"+id).html("<i class='fa fa-pause'></i>");
    }
    else {
        if (player.paused) {
            player.play(); // play again
            $("#btn"+id).html("<i class='fa fa-pause'></i>");
        }
        else {
            player.pause(); // pause
            $("#btn"+id).html("<i class='fa fa-play'></i>");
        }
    }
    currentSong = songName;
}

function loadAudio(event) {
    var files = event.target.files;
    player.src=URL.createObjectURL(files[0]);
    player.load(); // load song
    $("#play_button").show();
}
var audioFile = document.getElementById("audioFile");
if(audioFile) {
    audioFile.addEventListener("change", loadAudio, false);
}
function playsong() {
    if (player.paused) {
        player.currentTime=0;
        player.play(); // replay
        $("#play_button").html("<i class='fa fa-pause'></i>");
    }
    else {
        player.pause(); // pause
        $("#play_button").html("<i class='fa fa-play'></i>");
    }
}
/////////// audio player end ///////////////

$(document).on("change", "#jatio_dibos", function (e) {
    var fixed_type_id=$(this).val();
    $.ajax({
        type: "POST",
        url: base_url + "/show_sub_fixed_program_type",
        data: {fixed_type_id: fixed_type_id},
        'dataType': 'json',
        success: function (response) {
            $('#jatio_dibos_type').html('<option value="">বাছাই করুণ</option>');
            if (response.status == 'success') {
                $.each(response.data, function (index, Obj) {
                    $('#jatio_dibos_type').append('<option value="' + index + '">' + Obj + '</option>')
                })
            }
        }
    });

});


function autocompleteInstument(data) {
    var options = {
        minLength: 1,
        source: function (request, response) {
            $.ajax({
                url: base_url + "/get_instument",
                method: 'post',
                dataType: "json",
                autoFocus:true,
                data: {
                    term: request.term,
                },
                success: function (data) {
                    response(data);
                }
            });
        },
        select: function (event, ui) {
            console.log(ui);
            if(ui.item.name !='') {
                $('#instument').val(ui.item.label);
            }else{
                $('#instument').val('');
            }
            return false;
        }
    };

    $('body').on('keydown.autocomplete', '#instument', function() {
        $(this).autocomplete(options);
    });
}




function add_film_artist_row(){
    var artist_id = $("#film_actor").val();
    var tr = `
        <tr>
            <td>
                <input type="text" readonly placeholder="অভিনয় শিল্পী" name="film_actor[]" value="${artist_id}" class="form-control"/>
            </td>
            <td>
                <button type="button" onClick="this.parentNode.parentNode.remove()" class="btn btn-danger btn-sm"><i class="fa fa-minus"></i></button>
            </td>
        </tr>
    `;

    $("#film_artist_row").prepend(tr);
    $("#film_actor").val('');
}

function add_film_director_row(){
    var artist_id = $("#film_director").val();
    var tr = `
        <tr>
            <td>
                <input type="text" readonly placeholder="চলচিত্র পরিচালক" name="film_director[]" value="${artist_id}" class="form-control"/>
            </td>
            <td>
                <button type="button" onClick="this.parentNode.parentNode.remove()" class="btn btn-danger btn-sm"><i class="fa fa-minus"></i></button>
            </td>
        </tr>
    `;

    $("#film_director_row").prepend(tr);
    $("#film_director").val('');
}




$(document).ready(function (e) {


    $('.datepickerLong').datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
    }).val();

    $(".select2-ajax").select2({

        ajax: {
            url: base_url + "/get_artist_info",
            // url: "http://medilifeshl.com/bangladeshbetar/get_artist_info",
            dataType: 'json',
            data: function (params) {
                var searchid = this[0].attributes['searchid'].nodeValue;
                var query = {
                    search: params.term,
                    expertise_id: searchid
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            },
            processResults: function (data) {
                console.log(data);
                // Transforms the top-level key of the response object from 'items' to 'results'
                return {
                    results: data
                };
            }
        }

    });


    $(".select2-archiveids").select2({

        ajax: {
            url: base_url + "/get_archive_ids",
            // url: "http://medilifeshl.com/bangladeshbetar/get_artist_info",
            dataType: 'json',
            data: function (params) {
                var searchid = this[0].attributes['searchid'].nodeValue;
                var query = {
                    search: params.term,
                    archive_type: searchid
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            },
            processResults: function (data) {
                console.log(data);
                // Transforms the top-level key of the response object from 'items' to 'results'
                return {
                    results: data
                };
            }
        }

    });

    $(".select2-ajax-vumika").select2({

        ajax: {
            url: base_url + "/get_vumika_info",
            // url: "http://medilifeshl.com/bangladeshbetar/get_artist_info",
            dataType: 'json',
            data: function (params) {
                var searchid = this[0].attributes['searchid'].nodeValue;
                var query = {
                    search: params.term,
                    archive_type: searchid
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            },
            processResults: function (data) {
                console.log(data);
                // Transforms the top-level key of the response object from 'items' to 'results'
                return {
                    results: data
                };
            }
        }

    });


    $(".film_section,.band_section").css("display","none");

    $("#song_category").change(function(){
        var category = $(this).val();
        if(category==1){
            $(".film_section,.band_section").css("display","none");
        }
        else if(category==2){
            $(".film_section").css("display","block");
            $(".band_section").css("display","none");
        }
        else {
            $(".film_section").css("display","none");
            $(".band_section").css("display","block");
        }
    });


   

$("#song_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_song_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
}));

$("#kobita_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_kobita_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));


    $("#natok_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_natok_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));

    $("#program_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_program_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));

    $("#vhason_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_vhason_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));

    $("#sakhhatkar_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_sakhhatkar_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));

    $("#kothika_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_kothika_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));


    $("#procharona_create_form").on('submit',(function(e) {
        e.preventDefault();
        $('.ajax-loader').show();
        $('#saveing_text').html('Saveing--');
        $(":submit").attr("disabled", true);
        $.ajax({
            url: base_url + "/save_procharona_create", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {
                $('#saveing_text').html('Save');
                $(":submit").removeAttr("disabled");
                $('.ajax-loader').hide();
                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));




    // playlist create form
    $("#playlist_create_form").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: base_url + "/save_playlist", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {

                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));


    // playlist create form
    $("#playlist_update_form").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: base_url + "/save_playlist_update", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            'dataType': 'json',
            success: function(data)   // A function to be called if request succeeds
            {

                if (data.error.length > 0) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<div class="alert alert-danger">' + data.error[count] + '</div>';
                    }
                    $('#form_output_bank_info').html(error_html);
                } else {
                    $('#form_output_bank_info').html('');
                    swal({
                        text: data.success,
                        icon: "success",
                    }).then(function () {
                        location.reload();
                    });
                }
            }
        });
    }));






});

// playlist_update_form

function song_remove_from_playlist(song_id,playlist_id) {
    swal({
        title: "Are you sure?",
        text: "Once deleted, You will not be able to recover this record",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "POST",
                    url: base_url + "/song_remove",
                    data: {id: playlist_id,song_id:song_id},
                    'dataType': 'json',
                    success: function (response) {
                        if (response.status == 'success') {
                            swal({
                                text: response.message,
                                icon: "success",
                            }).then(function () {
                                location.reload();
                            });

                        } else {
                            swal(response.message, {
                                icon: "warning",
                            });
                        }
                    }
                });
            }
        });
}


function addToPlaylist(song_id) {
    var playlistName = $("#playlist_name").val();
    swal({
        title: "Are you sure added to playlist ?",
        text: "Your active playlist , "+playlistName,
        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
    .then((willDelete) => {
            if (willDelete) {
                var playlist_id = $("#playlist_id").val();
                $.ajax({
                    url: base_url + "/add_to_playlist", // Url to which the request is send
                    type: "POST",             // Type of request to be send, called as method
                    data: {song_id:song_id,playlist_id:playlist_id}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    'dataType': 'json',
                    success: function(data)   // A function to be called if request succeeds
                    {
                        swal({
                            text: 'song successfully added to active playlist',
                            icon: "success",
                        }).then(function () {
                            // location.reload();
                        });
                    }
                });
            } else {
                swal("Cancelled Now!");
            }
    });
}

function get_artist_name(id){
    var artist_data = JSON.parse($("#artist_json_data").val());
    if(artist_data.hasOwnProperty(id)){
        return artist_data[id];
    }
    
    return '';
}

function jontroshilpi_add() {
    var artist_id = $("#sound_artist").val();
    var hyperlink = $("#instument").val();
    var artist_name = get_artist_name(artist_id);
    $("#sound_artist").val('').trigger('change');
    var tr = `
        <tr>
            <td>
                <input type="hidden" readonly placeholder="যন্ত্রশিল্পীর নাম" name="instument_artist[]" value="${artist_id}" class="form-control"/>
           
                <input type="text" readonly class="form-control" value="${artist_name}"/>
            </td>
            <td>
                <input type="text" readonly placeholder="বাদ্যযন্ত্রের নাম" name="instument[]" value="${hyperlink}" class="form-control"/>
            </td>
            <td>
                <button type="button" onClick="this.parentNode.parentNode.remove()" class="btn btn-danger btn-sm"><i class="fa fa-minus"></i></button>
            </td>
        </tr>
    `;

    $("#sound_artist_info").prepend(tr);
    $("#instument").val('');
    $("#sound_artist").val('');

}

function reinitialize_vumika() {

    $(".select2-ajax-vumika").select2({

        ajax: {
            url: base_url + "/get_vumika_info",
            // url: "http://medilifeshl.com/bangladeshbetar/get_artist_info",
            dataType: 'json',
            data: function (params) {
                var searchid = this[0].attributes['searchid'].nodeValue;
                var query = {
                    search: params.term,
                    archive_type: searchid
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            },
            processResults: function (data) {
                console.log(data);
                // Transforms the top-level key of the response object from 'items' to 'results'
                return {
                    results: data
                };
            }
        }

    });
}

function reinitialize_artist(){
    $(".select2-ajax").select2({

        ajax: {
            url: base_url + "/get_artist_info",
            // url: "http://medilifeshl.com/bangladeshbetar/get_artist_info",
            dataType: 'json',
            data: function (params) {
                var searchid = this[0].attributes['searchid'].nodeValue;
                var query = {
                    search: params.term,
                    expertise_id: searchid
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            },
            processResults: function (data) {
                console.log(data);
                // Transforms the top-level key of the response object from 'items' to 'results'
                return {
                    results: data
                };
            }
        }

    });
}

vumika_id = 0;
function vumikashilpi_add() {
    // var artist_id = $("#vumika_artist").val();
    // var hyperlink = $("#vumika_id").val();
    // var artist_name = get_artist_name(artist_id);
    // $("#vumika_artist").val('').trigger('change');
    // $("#vumika_id").val('').trigger('change');
    vumika_id++;
    var tr = `
        <tr>
            <td>
                <select id="vumika_id" placeholder="ভুমিকা বাছাই করুণ" searchid="469" class="select2-ajax-vumika" name="vumika_id[${vumika_id}]" style="width:100%; !important">

                </select>
            </td>
            <td>
                <select id="vumika_artist" placeholder="অংশগ্রহণে" searchid="469" class="select2-ajax" multiple name="vumika_artist[${vumika_id}][]" style="width:100%; !important">

                </select>
            </td>
            <td>
                <button type="button" onClick="this.parentNode.parentNode.remove()" class="btn btn-danger btn-sm"><i class="fa fa-minus"></i></button>
            </td>
        </tr>
    `;

    $("#vumika_artist_info").append(tr);

    reinitialize_vumika();
    reinitialize_artist();

}

function get_song_sub_type(id) {
    $.ajax({
        url: base_url + "/get_song_sub_type", // Url to which the request is send
        type: "POST",             // Type of request to be send, called as method
        data: {id:id}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
        dataType: 'json',
        success: function(data)   // A function to be called if request succeeds
        {
            var options = "<option value=''>বাছাই করুন</option>";
            if(data.length>0) {
                for(var i=0; i<data.length;i++){
                    options+=`<option value='${data[i]['id']}'>${data[i]['name']}</option>`;
                }
            }

            $("#ganer_up_prokar").html(options);
            // console.log(data);
        }
    });
}
