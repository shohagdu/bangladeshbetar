
@extends("master_program")
@section('title_area')
    :: Costing ::  Program  ::
@endsection
@section('show_message')
    @if(Session::has('message'))
        <div class="alert alert-success alert-dismissible" id="alert_hide_after" role="alert"
             style="margin-bottom:10px; ">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ Session::get('message') }}
        </div>
    @endif
@endsection
@section('main_content_area')
    <article class="col-sm-12 col-md-12 col-lg-12">
        <!-- Widget ID (each widget will need unique ID)-->

        <div class="jarviswidget" id="wid-id-2" data-widget-colorbutton="false" data-widget-editbutton="false">
            <header>
                <span class="widget-icon"> <i class="fa fa-check txt-color-green"></i> </span>
                <h2> Costing :: Program ::</h2>
                <button onclick="print_fun()"
                        class="btn btn-warning btn-xs" style="float:right;margin-top:5px;margin-right:5px;"><i
                            class="glyphicon glyphicon-print"></i>
                    Print
                </button>
            </header>
            <div>
                 <div class="row">
                    <div class="col-sm-12">
                        <table class="table table-bordered" id="table-style">
                            <?php
                            $i = 1;
                            $total_amount = '0.00';

                            if(!empty($get_program_planning_info_artist)) {
                              //  echo "<pre>";
                               // print_r($get_program_planning_info_artist);
//                                exit;
                            foreach ($get_program_planning_info_artist as $key=> $description) {
                            if (!empty($program_plan->recorded_date)) {
                            $recorded_dt = !empty($program_plan->recorded_date) ? json_decode
                            ($program_plan->recorded_date, true) : '';
                            foreach ($recorded_dt as $recorded_date_info){
                            ?>
                                <tr>
                                    <td colspan="2">
                                        <table class="gate_passed_heading" style="width: 100%;" >
                                            <tr>
                                                <td style="font-size:14px!important;text-align:center;"
                                                >গণপ্রজাতন্ত্রী
                                                    বাংলাদেশ
                                                    সরকার</td>
                                            </tr>
                                            <tr>
                                                <td class="text-center" style="font-size:18px!important; ;font-weight:
                                                bold;">বাংলাদেশ
                                                    বেতার</td>
                                            </tr>
                                            <tr>
                                                <td class="text-center" >৩১, সৈয়দ মাহবুব মোরশেদ সরনি</td>
                                            </tr>
                                            <tr>
                                                <td class="text-center" >শেরে বাংলা নগর আগারগাও, ঢাকা-১২০৭ </td>
                                            </tr>
                                            <tr>
                                                <td class="text-center" >www.betar.gov.bd </td>
                                            </tr>
                                         </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="padding-top:10px !important;padding-bottom:50px !important;">
                                        <table class="gate_passed_body width90per">
                                            <tr>
                                                <th style="width:20%;">নাম</th>
                                                <td>{{ $description->artist_name }} </td>
                                            </tr>
                                            <tr>
                                                <th>মোবাইল</th>
                                                <td>
                                                    @php
                                                        $artist_mobile= !empty($description->artist_mobile)?json_decode
                                                         ($description->artist_mobile,true):'';
                                                        echo implode($artist_mobile);
                                                    @endphp
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>সাক্ষাতের উদ্দেশ্য</th>
                                                <td> {{$program_plan->program_name }} </td>
                                            </tr>
                                            <tr>
                                                <th>সাক্ষাতের তারিখ</th>
                                                <td>
                                                    {{ $recorded_date_info }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>সাক্ষাত প্রদানকারী</th>
                                                <td> </td>
                                            </tr>
                                            <tr>
                                                <th>গাডীর সহ গাডীর নং</th>
                                                <td> </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>







                            <?php
                            }
                            }
                            }

                            }
                            ?>
                        </table>


                    </div>

                </div>
            </div>
        </div>
    </article>

@endsection

