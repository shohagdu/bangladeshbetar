@extends("master_program")
@section('title_area')
    :: {{ $page_title }}  ::
@endsection
@section('show_message')
    @if(Session::has('message'))
        <div class="alert alert-success alert-dismissible" id="alert_hide_after" role="alert"
             style="margin-bottom:10px; ">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ Session::get('message') }}
        </div>
    @endif
@endsection
@section('main_content_area')
    <article class="col-sm-12 col-md-12 col-lg-12">
        <!-- Widget ID (each widget will need unique ID)-->
        <div class="jarviswidget" id="wid-id-2" data-widget-colorbutton="false" data-widget-editbutton="false">
            <header>
                <span class="widget-icon"> <i class="fa fa-check txt-color-green"></i> </span>
                <h2>{{ $page_title }}</h2>
            </header>
            <div>
                <div class="widget-body no-padding">
                    <div class="col-sm-12">
                        <div class="col-sm-12" style="margin-top:10px;"></div>
                        <table id="dt_basic" class="table table-striped table-bordered table-hover" width="100%">
                            <thead>
                            <tr>
                                <th style="width:5%;">SL</th>
                                <th> কেন্দ্র </th>
                                <th> আইডি</th>
                                <th> শিল্পীর নাম</th>
                                <th> </th>
                                <th> অনুষ্ঠানের নাম</th>
                                <th> ধরন</th>
                                <th>রেকডিং সময়</th>
                                <th>রেকডিং তারিখ</th>
                                <th>প্রযোজক</th>
                                <th>প্রস্তাব পাশকারী</th>

                                <th style="width: 140px"> #</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            $i = 1;
                          //  echo "<pre>";
//                            print_r($get_program_planning_info);
//                            exit;
                            ?>
                            @if(!empty($get_program_planning_info))
                                @foreach($get_program_planning_info as $singleData)

                                    <tr>
                                        <td> {{ $i++  }}</td>
                                        <td> {{ $singleData['station_name']  }}</td>
                                        <td> {{ $singleData['program_identity']  }}</td>
                                        <td> {{ $singleData['artist_name']  }}</td>
                                        <td> {{ $singleData['address']  }}</td>
                                        <td> {{ $singleData['program_name']  }}</td>
                                        <td> {{ $singleData['program_type_title']  }}</td>
                                        <td>
                                            {{ $singleData['recorded_time']  }}
                                        </td>
                                        <td>
                                            {{ $singleData['record_date']  }}
                                        </td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            <a href="{{ url('program_magazine_cost_view/'.$singleData['id'])
                                             }}" title="View" class="btn btn-success btn-xs"
                                            >
                                                <i class="glyphicon glyphicon-eye-open"></i> View
                                            </a>
                                            <a href="{{ url('gate_pass_print/'.$singleData['id'])
                                             }}" title="Print" class="btn btn-info btn-xs  ">
                                                <i class="glyphicon glyphicon-print"></i> Print
                                            </a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </article>





@endsection

