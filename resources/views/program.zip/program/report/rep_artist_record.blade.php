@extends("master_program")
@section('title_area')
    ::Report:: Program Artist Record  ::

@endsection
@section('show_message')
    @if(Session::has('message'))
        <div class="alert alert-success alert-dismissible" id="alert_hide_after" role="alert"
             style="margin-bottom:10px; ">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ Session::get('message') }}
        </div>
    @endif
@endsection
@section('main_content_area')
    <article class="col-sm-12 col-md-12 col-lg-12">

        <!-- Widget ID (each widget will need unique ID)-->
        <div class="jarviswidget" id="wid-id-2" data-widget-colorbutton="false" data-widget-editbutton="false">
            <header>
                <span class="widget-icon"> <i class="fa fa-check txt-color-green"></i> </span>
                <h2>Program Artist Report</h2>

                <button type="button" data-toggle="modal" onclick="AddProgramArtist()" data-target="#exampleModal"
                        class="btn btn-primary btn-xs" style="float:right;margin-top:5px;margin-right:5px;"><i
                            class="glyphicon glyphicon-list"></i>
                    Add New
                </button>

            </header>
            <div>
                <div class="widget-body no-padding">
                    <div class="col-sm-12">
                        <div class="col-sm-12" style="margin-top:10px;"></div>
                        <table id="dt_basic" class="table table-striped table-bordered table-hover" width="100%">
                            <thead>
                            <tr>
                                <th style="width:5%;">SL</th>
                                <th> শিল্পীর নাম</th>
                                <th> মোবাইল</th>
                                <th> ন্যাশানাল আই ডি</th>
                                <th> গ্রেড</th>
                                <th> তালিকাভুক্তির তারিখ</th>
                                <th> ঠিকানা</th>
                                <th style="width: 80px"> #</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            $i = 1;
                            ?>
                            @if(!empty($program_artist_info))
                                @foreach($program_artist_info as $singleData)
                                    <tr>
                                        <td>  {{ $i++  }}</td>
                                        <td>  {{ $singleData->name  }}</td>
                                        <td>  {{ $singleData->mobile  }}</td>
                                        <td>  {{ $singleData->national_id  }}</td>
                                        <td>
                                            @if($singleData->artist_grade==1))
                                            ক
                                            @elseif($singleData->artist_grade==2)
                                                খ
                                            @else
                                                গ
                                            @endif
                                        </td>
                                        <td>  {{ date('d-m-Y',strtotime($singleData->enlisted_date))  }}</td>
                                        <td>  {{ $singleData->address  }}</td>
                                        <td>
                                            <button type="button" data-toggle="modal" data-target="#exampleModal"
                                                    onclick="updateProgramArtist('{{ $singleData->id }}')"
                                                    class="btn btn-info btn-xs">
                                                <i class="glyphicon glyphicon-pencil"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </article>
    <!-- Modal -->
@endsection

